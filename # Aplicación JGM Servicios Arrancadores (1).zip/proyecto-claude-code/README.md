# 📱 JGM Arrancadores — Paquete de proyecto para Claude Code

Este paquete contiene **todo lo necesario** para que Claude Code construya la app **JGM Arrancadores** paso a paso. Está pensado para ejecutarse **desde el celular** (Claude Code en la nube + GitHub).

---

## 🚀 Cómo arrancar (leer esto primero)

1. Subí **toda esta carpeta** a tu repositorio de GitHub (el Paso 0 del plan te guía a crearlo).
2. Abrí el proyecto en **Claude Code**.
3. Escribile a Claude Code algo como:
   > *"Leé `CLAUDE.md` y `PLAN-DE-TRABAJO.md` y empezá por el Paso 0.1. Recordá parar en cada punto de control y esperar mi 'ok, siga'."*
4. A partir de ahí, avanzás **de a un paso por vez**, aprobando cada uno desde el celu.

---

## 📂 Qué hay en este paquete

```
proyecto-claude-code/
├── README.md                     ← este archivo
├── CLAUDE.md                     ← CONTEXTO MAESTRO (Claude Code lo lee siempre). Reglas, decisiones, seguridad.
├── PLAN-DE-TRABAJO.md            ← EL PLAN paso a paso (Fases 0 a 7, con puntos de control)
├── contexto/
│   ├── 01-vision-y-alcance.md    ← qué es y qué NO es la app
│   ├── 02-sistema-de-diseno.md   ← identidad JGM: colores, tipografía, temas, componentes
│   ├── 03-modelo-de-datos.md     ← estructura de datos "perfil de serie + variantes"
│   ├── 04-glosario-tecnico.md    ← términos técnicos + traducción (regla de idioma)
│   └── datos-extraidos/          ← DATOS REALES ya procesados de los manuales
│       ├── _INDICE.md
│       ├── weg-ssw05.md                     (✅ completo — modelo PILOTO)
│       ├── weg-ssw07.md                     (✅ completo)
│       ├── weg-ssw07-ssw08-programacion.md  (✅ perfil compartido SSW-07/08)
│       ├── lovato-adxl.md                   (✅ perfil de serie ADXL)
│       └── lovato-adxl0115600-datasheet.md  (✅ datasheet variante 115 A)
└── assets/
    └── jgm-logo.png              ← logo de JGM Servicios (para ícono y branding)
```

---

## 🧭 Resumen ultra-corto del proyecto

- **App:** JGM Arrancadores — PWA instalable, **offline**, para celular (Poco X7 Pro y Galaxy A25 5G).
- **Para qué:** guía técnica para **conectar, configurar y arrancar** arrancadores suaves. Catálogo por marca/modelo con diagramas interactivos, parámetros, protecciones, fallas y puesta en marcha.
- **Estrella:** 🔎 buscador de código de falla + 🧮 calculadora de parámetros.
- **No es** un registro de trabajos (no guarda clientes/fotos/PDF).
- **Stack:** React + Vite + PWA. **Hosting:** GitHub Pages. **Datos:** locales (IndexedDB), catálogo editable + respaldo por Export/Import.

---

## 🛑 Las 2 reglas que Claude Code no puede olvidar

1. **De a un paso por vez.** Al terminar cada paso: mostrar resultado → resumir → **esperar "ok, siga"**. Nunca encadenar pasos.
2. **Seguridad eléctrica.** Nunca inventar bornes, parámetros ni códigos de falla. Usar solo los datos de `contexto/datos-extraidos/`. Todo nace **sin verificar** hasta que el usuario aprueba. Cada dato cita su fuente.

(El detalle completo está en `CLAUDE.md`.)

---

## 📋 Estado del material técnico

| Marca / Modelo | Estado |
|---|---|
| WEG SSW-05 Plus | ✅ Completo — **modelo piloto** |
| WEG SSW-07 | ✅ Completo |
| WEG SSW-07/08 (programación) | ✅ Completo (perfil compartido) |
| Lovato ADXL (var. 0115600) | ✅ Completo |
| WEG SSW-08 (ficha propia) | 🟡 Falta User's Guide de hardware (el usuario lo consigue) |
| Otras marcas (Siemens, ABB, Schneider…) | ⏳ A sumar cuando haya manuales |

> El usuario irá sumando manuales. Al llegar uno nuevo: procesarlo → guardar extracción en `contexto/datos-extraidos/` → construir la ficha con el molde → aprobar.
